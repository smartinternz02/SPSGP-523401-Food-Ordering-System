package com.example.demo.Restaurant_Admin.Menu_Edit.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.database.QuickBitesMenu;

public interface QuickBites_Repository extends JpaRepository<QuickBitesMenu, Long> {

}
