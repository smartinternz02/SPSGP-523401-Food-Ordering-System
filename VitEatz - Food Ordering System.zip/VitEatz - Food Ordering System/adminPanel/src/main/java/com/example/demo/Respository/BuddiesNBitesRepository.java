package com.example.demo.Respository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.database.BuddiesNBitesMenu;

public interface BuddiesNBitesRepository extends CrudRepository<BuddiesNBitesMenu, Long>{

}
