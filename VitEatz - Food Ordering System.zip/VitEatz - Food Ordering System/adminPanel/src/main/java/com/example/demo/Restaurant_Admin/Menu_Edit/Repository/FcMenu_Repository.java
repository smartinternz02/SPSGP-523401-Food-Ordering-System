package com.example.demo.Restaurant_Admin.Menu_Edit.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.database.FcMenu;

public interface FcMenu_Repository extends JpaRepository<FcMenu, Long> {

}
